from flask import Blueprint, render_template, request, flash, jsonify, redirect, url_for
from flask_login import login_required, current_user
from .models import Task
from . import db
from datetime import datetime

add_tasks = Blueprint('add_tasks', __name__, template_folder='templates',
    static_folder='static')

@add_tasks.route('/add-task', methods=['GET', 'POST'])
@login_required
def add_task():
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        
        # Convert the due_date string to a Python date object
        due_date_str = request.form.get('due_date')
        due_date = datetime.strptime(due_date_str, '%Y-%m-%d').date()

        priority = request.form.get('priority')

        # Create a new task and add it to the database
        new_task = Task(title=title, description=description, due_date=due_date, priority=priority, user_id=current_user.id)
        db.session.add(new_task)
        db.session.commit()

        flash('Task added!', category='success')

        # Redirect back to the same "Add New Task" page
        return redirect(request.url)

    return render_template('add_tasks.html', user=current_user)
